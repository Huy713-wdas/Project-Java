Servlet+JSP Carbon Credit Marketplace (Buyer module)
- Uses SQLite (file: carbon_market.db)
- Import into VS Code and run on Tomcat (or Eclipse)
- Put sqlite-jdbc jar in lib/ and add to classpath when running on Tomcat.
- Paths:
  WebContent/jsp/buyer_marketplace.jsp
  WebContent/jsp/buyer_history.jsp
  src/controller/BuyerController.java
  src/dao/DBConnection.java
  src/dao/BuyerDAO.java
  src/model/CarbonCredit.java
  src/model/PurchaseHistory.java
  src/service/BuyerService.java
  database/init_sqlite.sql

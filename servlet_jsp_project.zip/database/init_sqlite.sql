-- SQLite init script for carbon marketplace (buyer module)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS User (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    password TEXT,
    role TEXT,
    wallet_balance REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS EVData (
    evdata_id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER,
    distance REAL,
    co2_reduced REAL,
    date TEXT,
    FOREIGN KEY (owner_id) REFERENCES User(user_id)
);

CREATE TABLE IF NOT EXISTS CarbonCredit (
    credit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER,
    amount_co2 REAL,
    credit_value REAL,
    status TEXT,
    verified_by INTEGER,
    region TEXT,
    FOREIGN KEY (owner_id) REFERENCES User(user_id)
);

CREATE TABLE IF NOT EXISTS PurchaseHistory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    buyer_id INTEGER,
    credit_id INTEGER,
    price REAL,
    payment_method TEXT,
    certificate_url TEXT,
    date TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (buyer_id) REFERENCES User(user_id),
    FOREIGN KEY (credit_id) REFERENCES CarbonCredit(credit_id)
);

-- Insert demo data
INSERT INTO User (name, email, password, role, wallet_balance) VALUES ('Demo Buyer','buyer@example.com','pass','BUYER',1000);
INSERT INTO User (name, email, password, role, wallet_balance) VALUES ('Demo Owner','owner@example.com','pass','EV_OWNER',0);

INSERT INTO CarbonCredit (owner_id, amount_co2, credit_value, status, region) VALUES (2, 100.0, 1000.0, 'LISTED', 'Hanoi');
INSERT INTO CarbonCredit (owner_id, amount_co2, credit_value, status, region) VALUES (2, 50.0, 450.0, 'LISTED', 'HCMC');

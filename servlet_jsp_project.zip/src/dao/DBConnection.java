package dao;
import java.sql.*;

public class DBConnection {
    private static final String URL = "jdbc:sqlite:database/carbon_market.db";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}

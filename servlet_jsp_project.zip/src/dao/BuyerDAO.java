package dao;
import java.sql.*;
import java.util.*;
import model.CarbonCredit;
import model.PurchaseHistory;

public class BuyerDAO {

    public List<CarbonCredit> getCreditsByStatus(String status) {
        List<CarbonCredit> list = new ArrayList<>();
        String sql = "SELECT * FROM CarbonCredit WHERE status=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new CarbonCredit(
                    rs.getInt("credit_id"),
                    rs.getInt("owner_id"),
                    rs.getDouble("amount_co2"),
                    rs.getDouble("credit_value"),
                    rs.getString("status"),
                    rs.getString("region")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<CarbonCredit> searchCredits(String region, double minPrice, double maxPrice) {
        List<CarbonCredit> list = new ArrayList<>();
        String sql = "SELECT * FROM CarbonCredit WHERE region LIKE ? AND credit_value BETWEEN ? AND ? AND status='LISTED'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + (region == null ? "" : region) + "%");
            ps.setDouble(2, minPrice);
            ps.setDouble(3, maxPrice);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new CarbonCredit(
                    rs.getInt("credit_id"),
                    rs.getInt("owner_id"),
                    rs.getDouble("amount_co2"),
                    rs.getDouble("credit_value"),
                    rs.getString("status"),
                    rs.getString("region")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public void buyCredit(int buyerId, int creditId, String paymentMethod) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            String q1 = "SELECT owner_id, credit_value FROM CarbonCredit WHERE credit_id=?";
            try (PreparedStatement ps1 = conn.prepareStatement(q1)) {
                ps1.setInt(1, creditId);
                ResultSet rs = ps1.executeQuery();
                if (!rs.next()) return;
                int sellerId = rs.getInt("owner_id");
                double price = rs.getDouble("credit_value");

                String q2 = "UPDATE CarbonCredit SET status='SOLD' WHERE credit_id=?";
                try (PreparedStatement ps2 = conn.prepareStatement(q2)) {
                    ps2.setInt(1, creditId);
                    ps2.executeUpdate();
                }

                String q3 = "INSERT INTO PurchaseHistory(buyer_id, credit_id, price, payment_method, certificate_url, date) VALUES (?, ?, ?, ?, ?, datetime('now'))";
                try (PreparedStatement ps3 = conn.prepareStatement(q3)) {
                    ps3.setInt(1, buyerId);
                    ps3.setInt(2, creditId);
                    ps3.setDouble(3, price);
                    ps3.setString(4, paymentMethod);
                    ps3.setString(5, "certificate_" + creditId + ".pdf");
                    ps3.executeUpdate();
                }
                conn.commit();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public List<PurchaseHistory> getPurchaseHistory(int buyerId) {
        List<PurchaseHistory> list = new ArrayList<>();
        String sql = "SELECT * FROM PurchaseHistory WHERE buyer_id=? ORDER BY date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, buyerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new PurchaseHistory(
                    rs.getInt("id"),
                    rs.getInt("buyer_id"),
                    rs.getInt("credit_id"),
                    rs.getDouble("price"),
                    rs.getString("payment_method"),
                    rs.getString("certificate_url")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}

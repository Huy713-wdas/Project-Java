package service;
import dao.BuyerDAO;
import model.CarbonCredit;
import model.PurchaseHistory;
import java.util.List;

public class BuyerService {
    private BuyerDAO buyerDAO = new BuyerDAO();

    public List<CarbonCredit> getAvailableCredits() {
        return buyerDAO.getCreditsByStatus("LISTED");
    }

    public List<CarbonCredit> searchCredits(String region, double minPrice, double maxPrice) {
        return buyerDAO.searchCredits(region, minPrice, maxPrice);
    }

    public void purchaseCredit(int buyerId, int creditId, String paymentMethod) {
        buyerDAO.buyCredit(buyerId, creditId, paymentMethod);
    }

    public List<PurchaseHistory> getPurchaseHistory(int buyerId) {
        return buyerDAO.getPurchaseHistory(buyerId);
    }
}

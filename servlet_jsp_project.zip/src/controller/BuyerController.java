package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.List;
import model.CarbonCredit;
import service.BuyerService;

@WebServlet("/buyer")
public class BuyerController extends HttpServlet {
    private BuyerService buyerService = new BuyerService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "list":
                List<CarbonCredit> credits = buyerService.getAvailableCredits();
                request.setAttribute("credits", credits);
                request.getRequestDispatcher("jsp/buyer_marketplace.jsp").forward(request, response);
                break;

            case "search":
                String region = request.getParameter("region");
                double minPrice = 0;
                double maxPrice = 1000000;
                try {
                    String mp = request.getParameter("minPrice");
                    String xp = request.getParameter("maxPrice");
                    if (mp != null && !mp.isEmpty()) minPrice = Double.parseDouble(mp);
                    if (xp != null && !xp.isEmpty()) maxPrice = Double.parseDouble(xp);
                } catch (Exception e) { }
                List<CarbonCredit> filtered = buyerService.searchCredits(region, minPrice, maxPrice);
                request.setAttribute("credits", filtered);
                request.getRequestDispatcher("jsp/buyer_marketplace.jsp").forward(request, response);
                break;

            case "history":
                Integer buyerId = (Integer) request.getSession().getAttribute("userId");
                if (buyerId == null) buyerId = 1; // default demo user
                request.setAttribute("history", buyerService.getPurchaseHistory(buyerId));
                request.getRequestDispatcher("jsp/buyer_history.jsp").forward(request, response);
                break;

            default:
                response.sendRedirect("jsp/buyer_marketplace.jsp");
                break;
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("buy".equals(action)) {
            int creditId = Integer.parseInt(request.getParameter("creditId"));
            Integer buyerId = (Integer) request.getSession().getAttribute("userId");
            if (buyerId == null) buyerId = 1; // demo
            String payment = request.getParameter("payment");

            buyerService.purchaseCredit(buyerId, creditId, payment);
            response.sendRedirect("buyer?action=history");
        }
    }
}

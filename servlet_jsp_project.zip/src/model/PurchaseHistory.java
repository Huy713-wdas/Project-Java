package model;
public class PurchaseHistory {
    private int id;
    private int buyerId;
    private int creditId;
    private double price;
    private String paymentMethod;
    private String certificateUrl;

    public PurchaseHistory(int id, int buyerId, int creditId, double price, String paymentMethod, String certificateUrl) {
        this.id = id;
        this.buyerId = buyerId;
        this.creditId = creditId;
        this.price = price;
        this.paymentMethod = paymentMethod;
        this.certificateUrl = certificateUrl;
    }

    public int getId() { return id; }
    public int getBuyerId() { return buyerId; }
    public int getCreditId() { return creditId; }
    public double getPrice() { return price; }
    public String getPaymentMethod() { return paymentMethod; }
    public String getCertificateUrl() { return certificateUrl; }
}

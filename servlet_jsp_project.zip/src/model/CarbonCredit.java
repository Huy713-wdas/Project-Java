package model;
public class CarbonCredit {
    private int creditId;
    private int ownerId;
    private double amountCO2;
    private double creditValue;
    private String status;
    private String region;

    public CarbonCredit(int creditId, int ownerId, double amountCO2, double creditValue, String status, String region) {
        this.creditId = creditId;
        this.ownerId = ownerId;
        this.amountCO2 = amountCO2;
        this.creditValue = creditValue;
        this.status = status;
        this.region = region;
    }

    public int getCreditId() { return creditId; }
    public int getOwnerId() { return ownerId; }
    public double getAmountCO2() { return amountCO2; }
    public double getCreditValue() { return creditValue; }
    public String getStatus() { return status; }
    public String getRegion() { return region; }
}
